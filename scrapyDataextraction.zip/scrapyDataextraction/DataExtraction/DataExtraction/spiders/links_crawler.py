# -*- coding: utf-8 -*-
import scrapy


class LinksCrawlerSpider(scrapy.Spider):
    name = 'links_crawler'
    allowed_domains = ['craigslist.org']
    start_urls = ['https://chicago.craigslist.org/']

    def parse(self, response):
        deals =  response.xpath('//div[@class="housing"]//div[@id="sss"]//ul//li//a/@href').extract()
        for i in deals :
           yield{"links":i}
        