# -*- coding: utf-8 -*-
import scrapy
from DataExtraction.items import DataextractionItem

class CarSpider(scrapy.Spider):
    name = 'car'
    allowed_domains = ['craigslist.org']
#    start_urls = ['https://chicago.craigslist.org/d/cars-trucks/search/cta']
    def start_requests(self):
       with open('C:\\Users\\aksha\\OneDrive\\Documents\\Purdue\\Fall Module - 2\\Unstructured Data analytics\\Project\\scrapyDataextraction\\DataExtraction\\links.csv','r') as csvf:
         for url in csvf:
            yield scrapy.Request("https://chicago.craigslist.org"+url.strip())
    items = [];
    def parse(self, response):
        Type = response.xpath('//div[@class="cattitle"]/a[@class="reset"]/text()').extract_first()
        deals =  response.xpath('//a[@class="result-image gallery"]')
        print(deals)
        deals =  response.xpath('//p[@class="result-info"]')
        for deal in deals:
            titles = deal.xpath('a[@class="result-title hdrlnk"]/text()').extract_first()
            dates = deal.xpath('time[@class="result-date"]/text()').extract_first()
            price = deal.xpath('span[@class="result-meta"]/span[@class="result-price"]/text()').extract_first()
            sites = deal.xpath('a[@class="result-title hdrlnk"]/@href').extract_first()
            item = DataextractionItem();
            item["Title"] = str(titles).strip().rstrip()
            item["Date"] = str(dates).strip().rstrip()
            item["Price"] = str(price).strip().rstrip()
            item["Type"] = str(Type).strip().rstrip()
            next_rel_url = response.xpath('//a[@class="button next"]/@href').extract_first() 
            next_url = response.urljoin(next_rel_url)
            yield scrapy.Request(sites, callback=self.parse_attr,meta ={'item':item})
            yield scrapy.Request(next_url, callback=self.parse)
    
    def parse_attr(self,response):
        text = "".join(line for line in response.xpath('//*[@id="postingbody"]/text()').extract())
        imageref = response.xpath('//img/@src').extract_first()
        #description = response.xpath('//section[@id="postingbody"]/text()').extract()
        item = response.meta['item']
        item = response.meta['item']
        title = str(item["Title"]).strip().rstrip()
        Date = str(item["Date"]).strip().rstrip()
        Price = str(item["Price"]).strip().rstrip()
        Type = str(item["Type"]).strip().rstrip()
        url_final = response.urljoin(imageref)
        #item["image_urls"] = str(imageref)
        #        description = str(text).strip().rstrip()
        yield DataextractionItem(Title=title, Date=Date,Type = Type, Price=Price,Description=text,image_urls = [url_final])
#        yield DataextractionItem(Title=title, Date=Date,Type = Type, Price=Price,Description=text)
