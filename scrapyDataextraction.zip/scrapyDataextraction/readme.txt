 The following code has to be executed in the following format. 
1)Please run the scrapy and point the scrapy to this folder
2) run the spider called links_crawler - this crawler will pull all the links on the craigslist
3) Remove the headers from excel file and save it with the same name.
4) Run the spyder called cars - to extract all the images and description of each  
5)It saves all the image and csv files to your machine.
6) After that execute the text extraction code, maintaining all the paths correctly.
7) This should yeild the results to you. 

